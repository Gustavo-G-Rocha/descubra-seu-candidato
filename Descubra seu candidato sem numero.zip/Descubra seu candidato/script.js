const cidadesPorEstado = {
  
    BA: ["Salvador", "Lauro de Freitas"],
    CE: ["Fortaleza"],
    GO: [ "Goiânia","Anápolis"],
    PE: ["Recife"],
    MG: ["Chapada Gaúcha", "Pitangui", "Pouso Alegre"],
    PR: ["Curitiba", "Londrina", "Pinhais"],
    RJ: [ "Rio de Janeiro", "Niterói"],
    RN: ["Natal", "Ceará Mirim"],
    SE: ["Aracaju"],
    RS: [ "Porto Alegre", "Nova Santa Rita"],
    SC: ["Joinville"],
    SP: ["São Paulo", "Americana", "Arujá", "Cruzeiro", "Franca", "Guarulhos", "Ibiúna", "Itu", "Lençóis Paulista", "Limeira", "Meridiano", "Osasco", "Piracicaba", "Ribeirão Preto", "Rio Claro", "Santa Barbara do Oeste", "Santo André", "São Bernardo do Campo", "São Caetano do Sul", "São José dos Campos", "São Luiz do Paraitinga",  "São Vicente", "Sorocaba"],

};

const candidatos = {
    BA: [ 
        { municipio: "Salvador", nome: "Sandro Filho", numeroEleitoral: "11000", foto: "images/sandrofilho.jpg", whatsapp: "https://chat.whatsapp.com/DT3PqlKIHW87zorIf9liE5", instagram: "https://www.instagram.com/sandrofilhombl/", tiktok: "https://www.tiktok.com/@sandrofilhombl", twitter: "https://x.com/SandroFilhoMBL", facebook:" https://www.facebook.com/sandrofilhombl", youtube:" https://www.youtube.com/@sandrofilhombl" },
        { municipio: "Lauro de Freitas", nome: "Andrei Castro", numeroEleitoral: "11100", foto: "images/andreicastro.jpg", whatsapp: "https://chat.whatsapp.com/H0UDDNO4LvY2QENGw9Evyo", instagram: "https://www.instagram.com/andreicastrombl/", tiktok: "https://www.tiktok.com/@andreicastrombl", twitter: "https://x.com/andreicastrombl", facebook:"https://www.facebook.com/profile.php?id=100077753006886 ", youtube:"https://www.youtube.com/@andreicastrombl " },

    ],
    CE: [
        { municipio: "Fortaleza", nome: "Pedro Arthur", numeroEleitoral: "44999", foto: "images/pedrinho.jpg", whatsapp: "https://chat.whatsapp.com/FILUUvHwTMFC7YdPT9cz1A", instagram: "https://www.instagram.com/pedroarthurce/", tiktok: "https://www.tiktok.com/@pedroarthurce", twitter: "https://x.com/PedroArthurMBL", facebook:"https://www.facebook.com/Pedrolima.MBL", youtube:" https://www.youtube.com/@pedroarthurce" },

    ],
    GO: [
        { municipio: "Goiânia", nome: "Noleto", numeroEleitoral: "77200", foto: "images/joaonoleto.jpg", whatsapp: "https://chat.whatsapp.com/LmDelRQY0YI4oKjWJBQc70/", instagram: "https://www.instagram.com/noletombl/", tiktok: "https://www.tiktok.com/@noletombl", twitter: "https://x.com/NoletoMBL", facebook:" https://www.facebook.com/joaornoleto?mibextid=JRoKGi", youtube:"https://youtube.com/@noletombl?si=OeU6FFP5rFXBih5G " },
        { municipio: "Anápolis", nome: "Luiz Fernando", numeroEleitoral: "12123", foto: "images/luizfernando.jpg", whatsapp: "https://chat.whatsapp.com/Da9rProoLSx9md3Y63JoeL", instagram: "https://www.instagram.com/luizfernandoaps/", tiktok: "https://www.tiktok.com/@luizfernandoaps", twitter: "https://x.com/luizfernaps" , facebook:"https://www.facebook.com/luizfernandoaps ", youtube:" "},

    ],
    MG: [
        { municipio: "Chapada Gaúcha", nome: "Luana", numeroEleitoral: "20700", foto: "images/luanagomes.jpg", whatsapp: "https://chat.whatsapp.com/Bi4QyYqmfvD6puLOdmWRvu", instagram: "https://www.instagram.com/luanasilvamgs/", tiktok: "https://www.tiktok.com/@luanagsilvamgs", twitter: "https://x.com/luanasilvamgs", facebook:" ", youtube:" " },
        { municipio: "Pitangui", nome: "Caio Caldas", numeroEleitoral: "22000", foto: "images/caiocaldas.jpg", whatsapp: "https://chat.whatsapp.com/BmmWzes9ZT4IUofqbAmxpR", instagram: "https://www.instagram.com/caiocaldasmg/", tiktok: "https://www.tiktok.com/@caiocaldasmg", twitter: "https://x.com/caiocaldasmg", facebook:"https://www.facebook.com/caiio123?mibextid=LQQJ4d ", youtube:" https://youtube.com/@caiocaldasmg?si=zLXDJ-icdzcT0OpJ" },
        { municipio: "Pouso Alegre", nome: "Israel Russo", numeroEleitoral: "44333", foto: "images/israelrusso.jpg", whatsapp: "https://chat.whatsapp.com/D6AhatHMJJ29LtKzz9vDvd", instagram: "https://www.instagram.com/russombl/", tiktok: "https://www.tiktok.com/@russombl", twitter: "https://x.com/russombl", facebook:"https://www.facebook.com/russombl ", youtube:"https://www.youtube.com/@russombl " },
    ],
    PR: [
        { municipio: "Curitiba", nome: "João Bettega", numeroEleitoral: "44777", foto: "images/joaobettega.jpg", whatsapp: "https://chat.whatsapp.com/E3dz6RI0hXP7qYWWu1jXUv", instagram: "https://www.instagram.com/bettega_/", tiktok: "https://www.tiktok.com/@joaobettega_", twitter: "https://x.com/joaobettega_", facebook:" https://www.facebook.com/joaobettegacuritiba/", youtube:" https://www.facebook.com/joaobettegacuritiba/" },
        { municipio: "Pinhais", nome: "Gustavo Camillo", numeroEleitoral: "44000", foto: "images/camillo.jpg", whatsapp: "https://chat.whatsapp.com/F9cCvjbfE9BJ372506nWpA", instagram: "https://www.instagram.com/camillopr_/", tiktok: "https://www.tiktok.com/@camillopr_",  twitter: "https://x.com/camillopr_", facebook:"https://www.facebook.com/profile.php?id=61551717190765&mibextid=LQQJ4d ", youtube:"https://youtube.com/@camillopr_?si=DRU5_xgwIX81A0pF " },
        { municipio: "Londrina", nome: "Gabriel Bertolucci", numeroEleitoral: "45000", foto: "images/bertoluccci.jpg", whatsapp: "https://chat.whatsapp.com/LFzHDa7jEjV8TdyAjekFQY", instagram: "https://www.instagram.com/bertolucci_br/", tiktok: "https://www.tiktok.com/@bertolucci.gabriel", twitter: "https://x.com/BertolucciGab", facebook:" ", youtube:" https://www.youtube.com/@BertolucciGabriel" },

    ],
    PE: [
        { municipio: "Recife", nome: "Sávio Rodrigues", numeroEleitoral: "55333", foto: "images/savio.jpg", whatsapp: "https://chat.whatsapp.com/Kx6jRe5e5xtGLeoYwhrmUH", instagram: "https://www.instagram.com/saviorodripe/", tiktok: "https://www.tiktok.com/@saviorodripe", twitter: "https://x.com/saviorodripe", facebook:"https://www.facebook.com/saviorodripe ", youtube:"https://www.youtube.com/@Saviorodripe " },
    ],
    
    RJ: [
        { municipio: "Niterói", nome: "Bernardo Sampaio", numeroEleitoral: "20000", foto: "images/bernardosampaio.jpg", whatsapp: "https://chat.whatsapp.com/L98m3Dy9rN2Htf0iRQs2BT", instagram: "https://www.instagram.com/berrsampaio/", tiktok: "https://www.tiktok.com/@berrsampaio", twitter: "https://x.com/berrsampaio", facebook:" ", youtube:" " },
        { municipio: "Rio de Janeiro", nome: "Gabriel Costenaro", numeroEleitoral: "30333", foto: "images/costenaro.jpg", whatsapp: "https://chat.whatsapp.com/LjYq2XpIjlqL18tVIrFxds", instagram: "https://www.instagram.com/costenarorj/", tiktok: "https://www.tiktok.com/@costenarorj", twitter: "https://x.com/CostenaroRJ", facebook:"https://facebook.com/costenarorj/ ", youtube:"https://youtube.com/@costenarorj?si=_Rnzf5ZAyhCRmRcW " },
        { municipio: "Rio de Janeiro", nome: "Pedro Duarte", numeroEleitoral: "30300", foto: "images/pedroduarte.jpg", whatsapp: "https://bit.ly/ComunidadeDoDuarte", instagram: "https://www.instagram.com/pedroduarterio/", tiktok: "https://www.tiktok.com/@pedroduarterio", twitter: "https://x.com/pedroduarterio", facebook:" https://www.facebook.com/pedroduarterio/", youtube:"https://www.youtube.com/@PedroDuarteRio " },

    ],
    RN: [
        { municipio: "Ceará Mirim", nome: "Arthur Souza", numeroEleitoral: "22999", foto: "images/arthursouza.jpg", whatsapp: "https://chat.whatsapp.com/EyIwjRscf8B9SPhMZ3tebw", instagram: "https://www.instagram.com/arthursouzarn/", tiktok: "https://www.tiktok.com/@arthursouzarn", twitter: "https://x.com/arthursouzarn", facebook:" ", youtube:"https://youtube.com/@arthursouzarn?si=FqNjrTFDdDG43eUN " },
        { municipio: "Natal", nome: "Matheus Faustino", numeroEleitoral: "44333", foto: "images/faustino.jpg", whatsapp: "#", instagram: "https://www.instagram.com/faustinorn/", tiktok: "https://www.tiktok.com/@faustinornoficial", twitter: "https://x.com/faustinorn01", facebook:" ", youtube:" https://www.youtube.com/@FaustinoRN" },
  
    ],
    RS: [
        { municipio: "Nova Santa Rita", nome: "Esdras", numeroEleitoral: "11777", foto: "images/esdrasdelima.jpg", whatsapp: "https://chat.whatsapp.com/BXkx9wdK26O7Dxrm9BUg4g", instagram: "https://www.instagram.com/esdrasdelimaalves/", tiktok: "https://www.tiktok.com/@esdrasdelimaalves", twitter: "https://x.com/EsdrasdeLimaAlv", facebook:"https://www.facebook.com/esdras.delimaalves ", youtube:"https://www.youtube.com/@esdrasdelimaalves " },
        { municipio: "Porto Alegre", nome: "Klaus Schuch", numeroEleitoral: "30999", foto: "images/klausschuch.jpg", whatsapp: "https://chat.whatsapp.com/Cvw1zapxvGJ7Tx56uYtm05", instagram: "https://www.instagram.com/alemaoklaus/", tiktok: "https://www.tiktok.com/@klauschuchpoa1", twitter: "https://x.com/Alemaoklaus_", facebook:" ", youtube:" https://youtube.com/@alemaoklaus?si=b8fWEAU1keJAI-M8" },


    ],
    SC: [
        { municipio: "Joinville", nome: "Mateus Batista", numeroEleitoral: "44333", foto: "images/mateusbatista.jpg", whatsapp: "https://chat.whatsapp.com/IJbD6byfXua0kttxGKLza5", instagram: "https://www.instagram.com/mateusbatistasc/", tiktok: "https://www.tiktok.com/@mateusbatistasc", twitter: "https://x.com/mateusbatistasc", facebook:" ", youtube:"https://www.youtube.com/@mateusbatistasc " },
    ],
    SE: [
        { municipio: "Aracaju", nome: "Davi Valença", numeroEleitoral: "10300", foto: "images/davicarvalho.jpg", whatsapp: "https://chat.whatsapp.com/EzvR5AIQwjXHPf02vnL3cv", instagram: "https://www.instagram.com/davivalencambl/", tiktok: "https://www.tiktok.com/@davivalencambl", twitter: "https://x.com/davivalencambl", facebook:"https://www.facebook.com/profile.php?id=100091940652597&mibextid=ZbWKwL ", youtube:"https://youtube.com/@davivalencambl?si=y2szT4t_t0VzhFyA " },

    ],
    SP: [
        { municipio: "Americana", nome: "Rafael Macris", numeroEleitoral: "11222", foto: "images/rafaelmacris.jpg", whatsapp: "https://chat.whatsapp.com/Le2KUliWnuvGT26De8wKj9", instagram: "https://www.instagram.com/rafamacris/", tiktok: "https://www.tiktok.com/@rafaelmacris", twitter: "https://x.com/rafamacris", facebook:" ", youtube:" https://www.youtube.com/@rafaelmacris" },
        { municipio: "Arujá", nome: "Gustavo Françoso", numeroEleitoral: "11111", foto: "images/francoso.png", whatsapp: "https://chat.whatsapp.com/EPDT6g4Y4NgIetQ4WrUBX7", instagram: "https://www.instagram.com/francoso.gustavo/", tiktok: "https://www.tiktok.com/@francoso.gustavo", twitter: "https://x.com/gwfrancoso", facebook:"https://www.facebook.com/gustavo.francoso.319 ", youtube:"https://www.youtube.com/@gustavo.francoso " },
        { municipio: "Franca", nome: "Miguel Francisco", numeroEleitoral: "44333", foto: "images/miguelfrancisco.jpg", whatsapp: "https://chat.whatsapp.com/IQ1X8UyRlKQ7ApWxbPyLef", instagram: "https://www.instagram.com/miguelfranciscosp/", tiktok: "https://www.tiktok.com/@miguelfrancasp", twitter: "https://x.com/miguelfrancasp", facebook:" https://www.facebook.com/guiasmiguel", youtube:" " },
        { municipio: "Cruzeiro", nome: "Paulo Filipe", numeroEleitoral: "44333", foto: "images/paulofilipe.jpg", whatsapp: "#", instagram: "https://www.instagram.com/paulofilipecrz/", tiktok: "https://www.tiktok.com/@paulofilipecrz", twitter: "https://x.com/paulofilipecrz", facebook:"http://facebook.com/paulofilipemaria ", youtube:" https://www.youtube.com/@paulofilipecrz" },
        { municipio: "Guarulhos", nome: "Guilherme Tassole", numeroEleitoral: "44333", foto: "images/guilhermetassolle.jpg", whatsapp: "https://chat.whatsapp.com/Kcfzq7SgRZiA2PTHt6ZF3R", instagram: "https://www.instagram.com/guilherme_tassolle/", tiktok: "https://www.tiktok.com/@guilherme_tassolle", twitter: "https://x.com/gui_tassolle", facebook:"https://www.facebook.com/guilherme.tassole ", youtube:" https://www.youtube.com/@guilhermetassolle" },
        { municipio: "Ibiúna", nome: "Lucas", numeroEleitoral: "20123", foto: "images/lucaspires.jpg", whatsapp: "#", instagram: "https://www.instagram.com/veterinariolucaspires/", tiktok: "https://www.tiktok.com/@lucasvetoficial", twitter: "", facebook:"https://facebook.com/lucasvetoficial ", youtube:" " },
        { municipio: "Itu", nome: "Derek Canarin", numeroEleitoral: "44333", foto: "images/derek.jpg", whatsapp: "#", instagram: "https://www.instagram.com/derek_itu/", tiktok: "https://www.tiktok.com/@derek_itu", twitter: "https://x.com/Derek_itu", facebook:"https://www.facebook.com/derek.canarin ", youtube:" https://www.youtube.com/@derek_canarin" },
        { municipio: "Lençóis Paulista", nome: "Fabrício", numeroEleitoral: "20700", foto: "images/fabriciorofrigues.jpg", whatsapp: "#", instagram: "https://www.instagram.com/fabriciorodriguesmbl/", tiktok: "https://www.tiktok.com/@fabriciorodriguesmbl", twitter: "https://x.com/frodriguesmbl", facebook:"https://www.facebook.com/fabricio.rodrigues.56679 ", youtube:" https://www.youtube.com/@fabriciorodriguesmbl" },
        { municipio: "Limeira", nome: "Guto Schiavetto", numeroEleitoral: "11222", foto: "images/gutoschiavetto.jpg", whatsapp: "https://chat.whatsapp.com/CBcQSpHftXu2Q5stsiTdyp", instagram: "https://www.instagram.com/gutoschiavetto/", tiktok: "https://www.tiktok.com/@gutoschiavetto", twitter: "https://x.com/guto_schiavetto", facebook:"https://www.facebook.com/profile.php?id=100000857663139 ", youtube:"https://www.youtube.com/@gutoschiavetto " },
        { municipio: "Osasco", nome: "Arthur Scara", numeroEleitoral: "44333", foto: "images/arthurscarra.jpg", whatsapp: "https://chat.whatsapp.com/DI0RgdHboFj9LkSZhi7Eek", instagram: "https://www.instagram.com/arthur.scara/", tiktok: "https://www.tiktok.com/@arthur.scara", twitter: "https://x.com/arthur_scarance", facebook:"https://www.facebook.com/arthur.scarance/ ", youtube:" https://www.youtube.com/@arthur.scarance" },
        { municipio: "Ribeirão Preto", nome: "Kareb Gregoris", numeroEleitoral: "44333", foto: "images/karengregoris.jpg", whatsapp: "https://chat.whatsapp.com/E6Kzmo3vWiMDmhepCtyZbx", instagram: "https://www.instagram.com/karen_gregoris/", tiktok: "https://www.tiktok.com/@karen_gregoris", twitter: "https://x.com/KarenGregoris", facebook:"https://www.facebook.com/profile.php?id=61556069523719&mibextid=kFxxJD ", youtube:" https://www.youtube.com/@karen_gregoris" },
        { municipio: "Piracicaba", nome: "Luis Bena", numeroEleitoral: "36000", foto: "images/luizbena.jpg", whatsapp: "#", instagram: "https://www.instagram.com/luisbena.mbl/", tiktok: "", twitter: "https://x.com/luisbenambl", facebook:" https://www.facebook.com/luisbena.mbl", youtube:" https://www.youtube.com/@luisbena1407" },
        { municipio: "Rio Claro", nome: "Pyetro", numeroEleitoral: "44999", foto: "images/pyetromartins.jpg", whatsapp: "https://chat.whatsapp.com/EPMDz9VKkivCTeWabikbaP", instagram: "https://www.instagram.com/pyetromartins/", tiktok: "https://www.tiktok.com/@pyetrohmartins", twitter: "https://x.com/Pyetromblivre", facebook:"https://www.facebook.com/pyetro.martins ", youtube:" " },
        { municipio: "Santa Barbara do Oeste", nome: "Jesua Savazzi", numeroEleitoral: "10012", foto: "images/jesuasavazzi.jpg", whatsapp: "#", instagram: "https://instagram.com/jesuasavazzi/", tiktok: "https://www.tiktok.com/@jesua.savazzi", twitter: "https://x.com/jesua_savazzi", facebook:"https://web.facebook.com/jesua.kendy/ ", youtube:"https://www.youtube.com/@jesuasavazzi " },
        { municipio: "Santo André", nome: "Marcio Colombo", numeroEleitoral: "45030", foto: "images/colombo.jpg", whatsapp: "#", instagram: "https://www.instagram.com/marcio_colombo/", tiktok: "https://www.tiktok.com/@marcio_colombo", twitter: "https://x.com/marciocolombo", facebook:"https://www.facebook.com/marciocolombooficial ", youtube:" https://www.youtube.com/@MarcioColombo" },
        { municipio: "São Bernardo do Campo", nome: "Glauco Braido", numeroEleitoral: "15555", foto: "images/glaucobraido.jpg", whatsapp: "https://chat.whatsapp.com/HAlaktAwMhX8xhEsCI2lQD", instagram: "https://www.instagram.com/glauconbraido/", tiktok: "https://www.tiktok.com/@glaucobraido", twitter: "https://x.com/Glauconbraido", facebook:"https://www.facebook.com/glauconbraido ", youtube:" https://www.youtube.com/c/GlaucoBraido" },
        { municipio: "São Caetano do Sul", nome: "Pedro Umbelino", numeroEleitoral: "44777", foto: "images/pedroumbelino.jpg", whatsapp: "https://chat.whatsapp.com/FbS0R9cyArs1AJwSTbOvxu", instagram: "https://www.instagram.com/pedroumbelino_/", tiktok: "https://www.tiktok.com/@pedroumbelino_", twitter: "https://x.com/pedroumbelino_", facebook:"https://www.facebook.com/pedroumbelinooficial ", youtube:" " },
        { municipio: "São José dos Campos", nome: "Fernanda Schimitt", numeroEleitoral: "44333", foto: "images/fernandaschimitt.jpg", whatsapp: "https://chat.whatsapp.com/IEIMlznZjos3NZcJwMIHdD", instagram: "https://www.instagram.com/fernandaschmittmbl/", tiktok: "https://www.tiktok.com/@fernandaschmittmbl", twitter: "https://x.com/mblfernanda", facebook:"https://www.facebook.com/profile.php?id=61553830980248 ", youtube:" https://www.youtube.com/@fernandaschmittmbl" },
        { municipio: "São Luiz do Paraitinga", nome: "Tomazini", numeroEleitoral: "25555", foto: "images/gabrieltomazini.jpg", whatsapp: "#", instagram: "https://www.instagram.com/tomazinimbl/", tiktok: "https://www.tiktok.com/@tomazinimbl", twitter: "https://x.com/tomazinimbl", facebook:"https://www.facebook.com/gabriel.coelho.775?mibextid=LQQJ4d ", youtube:" https://youtube.com/@tomazinimbl?si=Ar3SgT-h3Q6krGhk" },
        { municipio: "São Paulo", nome: "Amanda Vettorazzo", numeroEleitoral: "44333", foto: "images/amanda.jpg", whatsapp: "https://chat.whatsapp.com/CBKUGhIcanH4G78H9fAkig", instagram: "https://www.instagram.com/amanda.vettorazzo/", tiktok: "https://www.tiktok.com/@amanda.vettorazzo", twitter: "https://x.com/Amandavettorazz", facebook:"https://www.facebook.com/avettorazzo ", youtube:"https://www.youtube.com/@AmandaVettorazzosp " },
        { municipio: "São Paulo", nome: "Renato Battista", numeroEleitoral: "44999", foto: "images/renato.jpg", whatsapp: "https://whatsapp.com/channel/0029VaIiZGXBvvsmiD5KnW1w", instagram: "https://www.instagram.com/renatobattistambl/", tiktok: "https://www.tiktok.com/@renatobattistambl", twitter: "https://x.com/renato_battista", facebook:"https://www.facebook.com/renatobattistambl ", youtube:"https://www.youtube.com/@RenatoBattista " },
        { municipio: "São Vicente", nome: "Monielle Freitas", numeroEleitoral: "20014", foto: "images/moniele.jpg", whatsapp: "https://whatsapp.com/channel/0029Vaf2MZALikg7T1NEso25", instagram: "https://www.instagram.com/amonielle/", tiktok: "https://www.tiktok.com/@amonielle?_t=8ovh30yjzwe&_r=1", twitter: "https://x.com/FreitasMonielle?t=5mSZhvuJnrTxlQUC_nM-mA&s=09", facebook:"https://www.facebook.com/amonielle?mibextid=LQQJ4d ", youtube:"https://youtube.com/@amonielle?si=ulbC9Jhl6vN0tTq3 " },
        { municipio: "Sorocaba", nome: "Italo Moreira", numeroEleitoral: "44190", foto: "images/italo.jpeg", whatsapp: "https://chat.whatsapp.com/LKUNzNc8gT67sRlulAHWgl", instagram: "https://www.instagram.com/italomoreirasp/", tiktok: "https://www.tiktok.com/@italomoreirasp", twitter: "https://x.com/italomoreirasp", facebook:"https://www.facebook.com/italomoreirasp ", youtube:"https://www.youtube.com/@ItaloMoreira " },
        { municipio: "Meridiano", nome: "Juliana Lima", numeroEleitoral: "55", foto: "images/julianalima.jpg", whatsapp: "https://chat.whatsapp.com/BfWtUg4kfeIDpWIL9m1MHF", instagram: "https://www.instagram.com/julianalima_adv/", tiktok: "https://www.tiktok.com/@julianalima_adv", twitter: "https://x.com/julianalima_adv", facebook:"https://www.facebook.com/julianalimamirandaadv/ ", youtube:"https://www.youtube.com/@julianalimaadv " },

    ],
};

function updateCities() {
    const estadoSelect = document.getElementById('estado');
    const cidadeSelect = document.getElementById('cidade');
    const estado = estadoSelect.value;

    cidadeSelect.innerHTML = '<option value="">Qual sua cidade?</option>';

    if (estado) {
        const cidades = cidadesPorEstado[estado];
        cidades.forEach(cidade => {
            const option = document.createElement('option');
            option.value = cidade;
            option.textContent = cidade;
            cidadeSelect.appendChild(option);
        });
    }
}

function updateCandidates() {
    const estadoSelect = document.getElementById('estado');
    const cidadeSelect = document.getElementById('cidade');
    const estado = estadoSelect.value;
    const cidade = cidadeSelect.value;

    const candidatesContainer = document.getElementById('candidates-container');
    candidatesContainer.innerHTML = '';

    if (estado && candidatos[estado]) {
        const filteredCandidatos = candidatos[estado].filter(candidato => !cidade || candidato.municipio === cidade);

        filteredCandidatos.forEach(candidato => {
            const candidateDiv = document.createElement('div');
            candidateDiv.className = 'candidate';

            candidateDiv.innerHTML = `
                <img src="${candidato.foto}" alt="${candidato.nome}">
                <div class="candidate-info">
                    <p><strong>Município:</strong> ${candidato.municipio}</p>
                    <p><strong>Nome:</strong> ${candidato.nome}</p>
                    <div class="social-links">
                        <a href="${candidato.whatsapp}" target="_blank"><img src="images/whatsapp.png" alt="WhatsApp"></a>
                        <a href="${candidato.instagram}" target="_blank"><img src="images/instagram.png" alt="Instagram"></a>
                        <a href="${candidato.tiktok}" target="_blank"><img src="images/tiktok.png" alt="TikTok"></a>
                        <a href="${candidato.twitter}" target="_blank"><img src="images/twitter.png" alt="Twitter"></a>
                    </div>
                </div>
            `;

            candidatesContainer.appendChild(candidateDiv);
        });
    }
}